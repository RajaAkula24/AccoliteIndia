package com.restassured.testcases;

public class demo6 {

}
